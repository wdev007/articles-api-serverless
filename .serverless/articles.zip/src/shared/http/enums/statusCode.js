"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusCode = void 0;
var StatusCode;
(function (StatusCode) {
    StatusCode[StatusCode["OK"] = 200] = "OK";
    StatusCode[StatusCode["CREATED"] = 201] = "CREATED";
    StatusCode[StatusCode["NO_CONTEN"] = 204] = "NO_CONTEN";
    StatusCode[StatusCode["BAD_REQUEST"] = 400] = "BAD_REQUEST";
    StatusCode[StatusCode["ERROR"] = 500] = "ERROR";
})(StatusCode = exports.StatusCode || (exports.StatusCode = {}));
//# sourceMappingURL=statusCode.js.map