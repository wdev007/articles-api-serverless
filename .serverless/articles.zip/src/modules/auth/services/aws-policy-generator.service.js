"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AwsPolicyGeneratorService = (function () {
    function AwsPolicyGeneratorService() {
    }
    AwsPolicyGeneratorService.generate = function (principalId, effect, methodArn, context) {
        var authResponse = {};
        authResponse.principalId = principalId;
        if (effect && methodArn) {
            authResponse.policyDocument = {
                Version: '2012-10-17',
                Statement: [{
                        Action: 'execute-api:Invoke',
                        Effect: effect,
                        Resource: methodArn,
                    }]
            };
        }
        if (context) {
            authResponse.context = context;
        }
        return authResponse;
    };
    return AwsPolicyGeneratorService;
}());
exports.default = AwsPolicyGeneratorService;
//# sourceMappingURL=aws-policy-generator.service.js.map