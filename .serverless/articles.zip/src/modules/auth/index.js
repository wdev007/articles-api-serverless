"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BasicAuthService = exports.AwsPolicyGeneratorService = exports.AuthService = void 0;
var auth_service_1 = require("./services/auth.service");
exports.AuthService = auth_service_1.default;
var aws_policy_generator_service_1 = require("./services/aws-policy-generator.service");
exports.AwsPolicyGeneratorService = aws_policy_generator_service_1.default;
var basic_auth_service_1 = require("./services/basic-auth.service");
exports.BasicAuthService = basic_auth_service_1.default;
//# sourceMappingURL=index.js.map